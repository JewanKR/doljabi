// src/api/authClient.ts
import type { components } from "./schema";

type LoginForm = components["schemas"]["LoginForm"];
type SignupForm = components["schemas"]["SignupForm"];
type LoginResponse = components["schemas"]["LoginResponse"];
type ApiResponse = components["schemas"]["ApiResponse"];

const API_BASE_URL = "https://121.177.219.180";

export async function login(data: LoginForm) {
  const res = await fetch(`${API_BASE_URL}/api/login`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify(data),
  });

  const body: LoginResponse = await res.json();

  return {
    status: res.status,
    data: body,
  };
}

export async function signup(data: SignupForm) {
  const res = await fetch(`${API_BASE_URL}/api/signup`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    credentials: "include",
    body: JSON.stringify(data),
  });

  const body: ApiResponse = await res.json();

  return {
    status: res.status,
    data: body,
  };
}
